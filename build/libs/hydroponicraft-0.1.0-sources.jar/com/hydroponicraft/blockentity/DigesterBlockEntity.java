package com.hydroponicraft.blockentity;

import com.hydroponicraft.HydroponiCraftFluids;
import com.hydroponicraft.HydroponiCraftRegistry;
import com.hydroponicraft.menu.DigesterMenu;
import com.hydroponicraft.recipe.DigesterRecipe;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.ItemStackHandler;

import javax.annotation.Nullable;
import java.util.Optional;

public class DigesterBlockEntity extends KineticBlockEntity implements MenuProvider {

    private static final Logger LOGGER = LogUtils.getLogger();

    /** Slots 0-2: organic inputs. Slot 3: byproduct output (reserved for future use). */
    public final ItemStackHandler itemHandler = new ItemStackHandler(4);

    /** Output tank — accepts only Nutrient Fluid, 8 000 mB capacity. */
    public final FluidTank fluidTank = new FluidTank(8_000) {
        @Override
        public boolean isFluidValid(FluidStack stack) {
            return stack.getFluid() == HydroponiCraftFluids.NUTRIENT_FLUID.get();
        }
    };

    private int processingTicks = 0;
    private int maxTicks        = 0;

    /** Synced to the client via the open container. */
    public final ContainerData containerData = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DigesterMenu.DATA_PROCESSING_TICKS -> processingTicks;
                case DigesterMenu.DATA_MAX_TICKS        -> maxTicks;
                case DigesterMenu.DATA_FLUID_AMOUNT     -> fluidTank.getFluidAmount();
                case DigesterMenu.DATA_FLUID_CAPACITY   -> fluidTank.getCapacity();
                case DigesterMenu.DATA_RPM              -> (int) Math.abs(getSpeed());
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DigesterMenu.DATA_PROCESSING_TICKS -> processingTicks = value;
                case DigesterMenu.DATA_MAX_TICKS        -> maxTicks = value;
            }
        }

        @Override
        public int getCount() { return DigesterMenu.DATA_COUNT; }
    };

    public DigesterBlockEntity(BlockPos pos, BlockState state) {
        super(HydroponiCraftRegistry.DIGESTER_BE.get(), pos, state);
    }

    // ------------------------------------------------------------------
    // MenuProvider
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.hydroponicraft.digester");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInv, Player player) {
        return new DigesterMenu(containerId, playerInv, this, containerData);
    }

    // ------------------------------------------------------------------
    // Ticking
    // ------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide()) return;
        LOGGER.info("Digester ticking, speed: " + getSpeed());
        if (!isSpeedRequirementFulfilled() || Math.abs(getSpeed()) < 1f) {
            processingTicks = 0;
            maxTicks = 0;
            return;
        }
        processRecipe();
    }

    private void processRecipe() {
        for (int slot = 0; slot < 3; slot++) {
            ItemStack stack = itemHandler.getStackInSlot(slot);
            if (stack.isEmpty()) continue;

            Optional<RecipeHolder<DigesterRecipe>> match = level.getRecipeManager()
                    .getRecipeFor(HydroponiCraftRegistry.DIGESTING_RECIPE_TYPE.get(),
                            new SingleRecipeInput(stack), level);
            if (match.isEmpty()) continue;

            DigesterRecipe recipe = match.get().value();

            if (fluidTank.getFluidAmount() + recipe.fluidOutputMb() > fluidTank.getCapacity()) {
                processingTicks = 0;
                maxTicks = 0;
                return;
            }

            // Speed scaling: base ticks assume 16 RPM; higher RPM → fewer ticks.
            maxTicks = Math.max(1, (int) (recipe.baseTicks() * 16.0 / Math.abs(getSpeed())));
            processingTicks++;

            if (processingTicks >= maxTicks) {
                processingTicks = 0;
                itemHandler.extractItem(slot, 1, false);
                fluidTank.fill(
                        new FluidStack(HydroponiCraftFluids.NUTRIENT_FLUID.get(), recipe.fluidOutputMb()),
                        IFluidHandler.FluidAction.EXECUTE);
                setChanged();
            }
            return;
        }
        processingTicks = 0;
        maxTicks = 0;
    }

    // ------------------------------------------------------------------
    // NBT persistence
    // ------------------------------------------------------------------

    @Override
    public void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.put("Inventory", itemHandler.serializeNBT(registries));
        tag.put("FluidTank", fluidTank.writeToNBT(registries, new CompoundTag()));
        tag.putInt("ProcessingTicks", processingTicks);
        tag.putInt("MaxTicks", maxTicks);
    }

    @Override
    public void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        itemHandler.deserializeNBT(registries, tag.getCompound("Inventory"));
        fluidTank.readFromNBT(registries, tag.getCompound("FluidTank"));
        processingTicks = tag.getInt("ProcessingTicks");
        maxTicks = tag.getInt("MaxTicks");
    }
}
