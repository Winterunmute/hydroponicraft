package com.hydroponicraft.screen;

import com.hydroponicraft.HydroponiCraftMod;
import com.hydroponicraft.menu.DigesterMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class DigesterScreen extends AbstractContainerScreen<DigesterMenu> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(HydroponiCraftMod.MOD_ID, "textures/gui/digester.png");

    // Background region in the texture (left 176px of the 256-wide PNG)
    private static final int BG_WIDTH  = 176;
    private static final int BG_HEIGHT = 166;

    // Filled arrow sprite — at texture x=176, y=47; max size 22×16
    private static final int ARROW_SPRITE_U  = 176;
    private static final int ARROW_SPRITE_V  = 47;
    private static final int ARROW_MAX_WIDTH = 22;
    private static final int ARROW_HEIGHT    = 16;
    // Screen position of the arrow (matches the empty outline baked into the background)
    private static final int ARROW_SCREEN_X  = 80;
    private static final int ARROW_SCREEN_Y  = 47;

    // Filled tank bar sprite — at texture x=198, y=17; max size 18×76
    private static final int TANK_SPRITE_U   = 198;
    private static final int TANK_SPRITE_V   = 17;
    private static final int TANK_BAR_WIDTH  = 18;
    private static final int TANK_MAX_HEIGHT = 76;
    // Screen position of the tank (matches the empty outline baked into the background)
    private static final int TANK_SCREEN_X   = 53;
    private static final int TANK_SCREEN_Y   = 14;

    public DigesterScreen(DigesterMenu menu, Inventory playerInv, Component title) {
        super(menu, playerInv, title);
        this.imageWidth  = BG_WIDTH;
        this.imageHeight = BG_HEIGHT;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        // Draw the background (left 176×166 region of the texture)
        guiGraphics.blit(TEXTURE, leftPos, topPos, 0, 0, BG_WIDTH, BG_HEIGHT, 256, BG_HEIGHT);

        renderFluidBar(guiGraphics);
        renderProgressArrow(guiGraphics);
    }

    private void renderFluidBar(GuiGraphics guiGraphics) {
        int capacity = menu.getFluidCapacity();
        if (capacity <= 0) return;
        int filledPixels = (int) (TANK_MAX_HEIGHT * (menu.getFluidAmount() / (float) capacity));
        if (filledPixels <= 0) return;

        // Blit from the bottom of the sprite upward so an empty tank looks empty at the bottom.
        // vOffset shifts the source V down to the bottom-most filled slice.
        int vOffset = TANK_MAX_HEIGHT - filledPixels;
        guiGraphics.blit(TEXTURE,
                leftPos  + TANK_SCREEN_X,
                topPos   + TANK_SCREEN_Y + vOffset,
                TANK_SPRITE_U,
                TANK_SPRITE_V + vOffset,
                TANK_BAR_WIDTH,
                filledPixels,
                256, BG_HEIGHT);
    }

    private void renderProgressArrow(GuiGraphics guiGraphics) {
        int maxTicks = menu.getMaxTicks();
        if (maxTicks <= 0) return;
        int filledPixels = (int) (ARROW_MAX_WIDTH * (menu.getProcessingTicks() / (float) maxTicks));
        if (filledPixels <= 0) return;

        guiGraphics.blit(TEXTURE,
                leftPos  + ARROW_SCREEN_X,
                topPos   + ARROW_SCREEN_Y,
                ARROW_SPRITE_U,
                ARROW_SPRITE_V,
                filledPixels,
                ARROW_HEIGHT,
                256, BG_HEIGHT);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        renderTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        super.renderLabels(guiGraphics, mouseX, mouseY);

        // RPM indicator — right-aligned near the top of the GUI
        int rpm = menu.getRPM();
        String rpmText = rpm + " RPM";
        guiGraphics.drawString(font, rpmText,
                imageWidth - font.width(rpmText) - 8, 7, 0x404040, false);
    }
}
