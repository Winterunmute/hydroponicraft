package com.hydroponicraft.menu;

import com.hydroponicraft.HydroponiCraftRegistry;
import com.hydroponicraft.blockentity.DigesterBlockEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.items.SlotItemHandler;

public class DigesterMenu extends AbstractContainerMenu {

    // ContainerData indices
    public static final int DATA_PROCESSING_TICKS = 0;
    public static final int DATA_MAX_TICKS         = 1;
    public static final int DATA_FLUID_AMOUNT      = 2;
    public static final int DATA_FLUID_CAPACITY    = 3;
    public static final int DATA_RPM               = 4;
    public static final int DATA_COUNT             = 5;

    private final DigesterBlockEntity blockEntity;
    private final ContainerData data;

    // Network (client-side) constructor — reads block pos from the extra data buffer.
    public DigesterMenu(int containerId, Inventory playerInv, FriendlyByteBuf buf) {
        this(containerId, playerInv, getBlockEntity(playerInv, buf), new SimpleContainerData(DATA_COUNT));
    }

    // Server-side constructor.
    public DigesterMenu(int containerId, Inventory playerInv, DigesterBlockEntity be, ContainerData data) {
        super(HydroponiCraftRegistry.DIGESTER_MENU.get(), containerId);
        this.blockEntity = be;
        this.data = data;
        addDataSlots(data);

        // --- Block entity item slots ---
        // Input slots (left column)
        addSlot(new SlotItemHandler(be.itemHandler, 0, 26, 17));
        addSlot(new SlotItemHandler(be.itemHandler, 1, 26, 35));
        addSlot(new SlotItemHandler(be.itemHandler, 2, 26, 53));
        // Byproduct output (right side)
        addSlot(new SlotItemHandler(be.itemHandler, 3, 134, 35));

        // --- Player inventory (rows 0-2) ---
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));

        // --- Hotbar ---
        for (int col = 0; col < 9; col++)
            addSlot(new Slot(playerInv, col, 8 + col * 18, 142));
    }

    private static DigesterBlockEntity getBlockEntity(Inventory playerInv, FriendlyByteBuf buf) {
        BlockEntity be = playerInv.player.level().getBlockEntity(buf.readBlockPos());
        if (be instanceof DigesterBlockEntity digester) return digester;
        throw new IllegalStateException("No DigesterBlockEntity at position read from packet");
    }

    // ------------------------------------------------------------------
    // Shift-click logic
    // ------------------------------------------------------------------

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < 4) {
                // BE slot → player inventory
                if (!moveItemStackTo(stack, 4, 40, true)) return ItemStack.EMPTY;
            } else {
                // Player inventory → input slots (0-2)
                if (!moveItemStackTo(stack, 0, 3, false)) return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        if (blockEntity == null) return true;
        return AbstractContainerMenu.stillValid(
                ContainerLevelAccess.create(blockEntity.getLevel(), blockEntity.getBlockPos()),
                player, HydroponiCraftRegistry.DIGESTER_BLOCK.get());
    }

    // ------------------------------------------------------------------
    // Data accessors for the screen
    // ------------------------------------------------------------------

    public int getProcessingTicks() { return data.get(DATA_PROCESSING_TICKS); }
    public int getMaxTicks()        { return data.get(DATA_MAX_TICKS); }
    public int getFluidAmount()     { return data.get(DATA_FLUID_AMOUNT); }
    public int getFluidCapacity()   { return data.get(DATA_FLUID_CAPACITY); }
    public int getRPM()             { return data.get(DATA_RPM); }
}
